#RF.ipynb
1. RF.ipynb can train Randon Forest models with different hyperparameters

2. RF.ipynb can load different trained Randon Forest models (RF_count_model, RF_fare_model, RF_tip_model) to make predictions.

#RF_Tune.ipynb
RF_Tune.ipynb can tune the Random Forest model with different value of hyperparameters.

#Pre-trained Models
RF_count_model, RF_fare_model, RF_tip_model are the best trained models so far to predict Count, Fare and Tips.